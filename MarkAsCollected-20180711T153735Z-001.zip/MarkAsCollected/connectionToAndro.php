<?php
	// This file helps us to connect PHP and MYSQL with an android application
	
	$con = mysqli_connect("localhost:3306","root","","locations");	

	if(mysqli_connect_errno())
	{
		echo "Failed to connect:" . mysqli_connect_error();
	}
	
	
	$nameOfDonor = $_POST["yourName"];// ;
	
	
	$lat = $_POST["latitude"];//
	$lng = $_POST["longitude"];
	
	
	$sql = "INSERT INTO `locations`.`markers` (`NAME`, `REQUEST_ID`, `lat`, `lng`) VALUES ('$nameOfDonor', NULL, '$lat', '$lng')";
	
	
	$result = mysqli_query($con,$sql);
	//check if row is inserted properly
	if($result){
		//successfully inserted
		$response["success"] = 1;
		$response["message"] = "Pickup location registered";
		
		echo json_encode($response);
		
	}
	else{
		$response["success"] = 0;
		$response["message"] = "Pickup location not registered try again";
		
		echo json_encode($response);
	}
?>