<?php

$con = mysqli_connect("localhost:3306","root","","locations");	

	if(mysqli_connect_errno())
	{
		echo "Failed to connect:" . mysqli_connect_error();
	}
	
	$r_id = $_POST["req_id"];
	
	$sql = "UPDATE markers SET COLLECTION_STATUS = 1 WHERE REQUEST_ID = $r_id";

	$result = mysqli_query($con,$sql);
	

        echo "<script> location.href='to_print_n_update.html'; </script>";
        exit;

	
?>