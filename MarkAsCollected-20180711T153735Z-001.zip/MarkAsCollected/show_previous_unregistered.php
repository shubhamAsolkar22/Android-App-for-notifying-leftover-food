<?php

$username = "root";
$password = "";
$database = "locations";

$connection=mysql_connect('localhost', $username, $password);
if (!$connection) {  die('Not connected : ' . mysql_error());}

// Set the active MySQL database

$db_selected = mysql_select_db($database, $connection);
if (!$db_selected) {
  die ('Can\'t use db : ' . mysql_error());
}

  $query = "SELECT * FROM todays_requests ";    //markers
$result = mysql_query($query);
if (!$result) {
  die('Invalid query: ' . mysql_error());
}

//SELECT NAME, CONTACT_NO,Date_of_req FROM markers WHERE CONTACT_NO NOT IN (Select CONTACT_NO FROM markers where Date_of_req = CURRENT_DATE ) 
$query = "SELECT * FROM todays_non_redistered ";
$result = mysql_query($query);
if (!$result) {
  die('Invalid query: ' . mysql_error());
}
echo "<table border = '1' >
	<tr>
	<th>Donor</th>
	<th>CONTACT_NO</th>
	<th>Date_of_req</th>
	</tr>";
while ($row = @mysql_fetch_assoc($result)){
	echo "<tr><td>".$row['NAME']."</td>"."<td>".$row['CONTACT_NO']."</td>"."<td>".$row['Date_of_req']."</td></tr>";
	
}

echo "</table>";
?>